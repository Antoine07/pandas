import pandas as pd
import numpy as np


## Exercice création de DataFrame

fruit1 = pd.DataFrame({
    'Rapsberry' : [30],
    'Cherries'  : [20]
})

fruit2 = pd.DataFrame({
    'fig' : [130, 309],
    'wine'  : [120, 290]
    }, index=['2020', '2019']
)

## Exercice construire des objets de type Séries

values = range(1, 12, 2)
index = 'abcdef'

A = pd.Series(list(values), list(index))

# Exercices changez les index

"""
Mettez les codes des départements à la place des noms des villes dans la Series : **cities_s**
Bordeaux : 33, Paris : 75, Lille : 59
"""

cities = {
    'Bordeaux' : 249712  ,
    'Paris' : 2190327 ,
    'Lille' : 232741
}

cities_s = pd.Series(cities)

#Bordeaux : 33, Paris : 75, Lille : 59
departements = [33, 75, 59]
cities_s.index = departements

# Augmentation de 10%
cities_s = cities_s * 1.1

## Exercice Series & index

notes = pd.Series([13.4, 20, 10, 15, 14, 16])

subjects = [
'Databases', 'Culture',
'Git', 'Stat desc',
'Stat inf', 'Python'
]

notes.index = subjects
print(notes.median())

## Exercice apply

firstName = pd.Series([
    'adaline Reichel',
    'dr. Santa Prosacco DVM',
    'noemy Vandervort V',
    'lexi O Conner',
    'gracie Weber',
    'roscoe Johns',
    'emmett Lebsack',
    'keegan Thiel',
    'wellington Koelpin II',
    'ms. Karley Kiehn V',
])

## Exercice Séries A & B

## 1. Soit les deux Séries A et B suivantes, 
# récupérez les valeurs de la série A qui ne 
# sont pas présentes dans la série B.

A = pd.Series([1,21,13,14,59])
B = pd.Series([14,21,3,4,5, 1])

print(A.isin(B))
A[~A.isin(B)]

## 2. Récupérez toutes les valeurs de A et B 
# en excluant celles qui sont dans les deux en même temps.

print(A)
print(B)

U = pd.Series( np.union1d(A, B) )
Inter = pd.Series( np.intersect1d(A, B) )
print(U)
print(Inter)

print(U[~U.isin(Inter)])

## Exercice Moyenne avec deux Séries

fruits = pd.Series( np.random.choice(['banana', 'apple', 'raspberry'], 15))
# Respectivement chaque poids correspond à chaque fruit
weights = pd.Series( np.linspace(1.0, 2.0, 15) )

print(weights)

weights.groupby(fruits).mean()

## Exercice Remplacer et modifier

# Soit la chaîne de caractères suivantes :

characters ='abc def abe dae fab'

#1. Créez une Séries à partir de characters.

#2. Remplacez les chaînes vides par la valeur np.nan.

#3. Trouvez la fréquence de la lettre la moins représentée dans la Séries, puis remplacez les valeurs NAN par cette lettre.


A = pd.Series(list( characters ) )

A[ A ==' '] = np.nan

B = A.value_counts()
m = B[-1]
letter = ''
for i, a in B.items():
    if a == m:
        letter = i
        
A.fillna(value = letter, inplace= True)

print("".join(A))

## Exercice serie temporelle

import pandas as pd
import numpy as np

ser = pd.Series(
    np.random.randint(100,200,30), 
    index = pd.date_range('2019-01-01', periods=30, freq='W-TUE')
)
ser.index.name = 'Date'

print(ser.value_counts())

# dates pour les valeurs max et min
print( ser[ser == ser.max()] )
print( ser[ser == ser.min()] )

# somme des 5 dernières valeurs
print( ser[-5:].sum() )

